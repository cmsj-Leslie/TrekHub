/**
 * 评论控制器
 * 功能：评论列表（含子回复）、发表评论、删除评论、点赞
 */
const { Comment, User } = require('../models')
const { success, created, fail, notFound, forbidden } = require('../utils/response')

// 获取评论列表（支持按目标类型和ID查询，含子评论）
exports.list = async (req, res) => {
  const { target_type, target_id, page = 1, pageSize = 20 } = req.query
  if (!target_type || !target_id) return fail(res, '缺少参数')
  const { count, rows } = await Comment.findAndCountAll({
    where: { target_type, target_id, parent_id: null }, // 只查顶级评论
    order: [['created_at', 'DESC']],
    limit: +pageSize, offset: (page - 1) * pageSize,
    include: [
      { model: User, as: 'user', attributes: ['id', 'nickname', 'avatar'] },
      { model: Comment, as: 'replies', limit: 3, // 每条评论最多展示3条回复
        include: [{ model: User, as: 'user', attributes: ['id', 'nickname', 'avatar'] }] }
    ]
  })
  success(res, { total: count, list: rows })
}

// 发表评论（支持回复、评分、图片）
exports.create = async (req, res) => {
  const { target_type, target_id, content, parent_id, rating, images } = req.body
  if (!content?.trim()) return fail(res, '评论内容不能为空')
  const comment = await Comment.create({ target_type, target_id, user_id: req.user.id, content, parent_id, rating, images })
  const full = await Comment.findByPk(comment.id, {
    include: [{ model: User, as: 'user', attributes: ['id', 'nickname', 'avatar'] }]
  })
  created(res, full)
}

// 删除评论（仅评论作者可删除）
exports.remove = async (req, res) => {
  const comment = await Comment.findByPk(req.params.id)
  if (!comment) return notFound(res)
  if (comment.user_id !== req.user.id) return forbidden(res)
  await comment.destroy()
  success(res, null, '删除成功')
}

// 点赞/取消点赞评论（toggle）
exports.like = async (req, res) => {
  const sequelize = require('../config/db')
  const commentId = +req.params.id
  const userId = req.user.id

  // 确保 comment_likes 表存在
  await sequelize.query(`
    CREATE TABLE IF NOT EXISTS comment_likes (
      user_id    INT UNSIGNED NOT NULL,
      comment_id INT UNSIGNED NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (user_id, comment_id)
    )
  `)

  const comment = await Comment.findByPk(commentId)
  if (!comment) return notFound(res)

  // 检查是否已点赞
  const [existing] = await sequelize.query(
    'SELECT 1 FROM comment_likes WHERE user_id = ? AND comment_id = ?',
    { replacements: [userId, commentId], type: sequelize.QueryTypes.SELECT }
  )

  if (existing) {
    // 取消点赞
    await sequelize.query('DELETE FROM comment_likes WHERE user_id = ? AND comment_id = ?',
      { replacements: [userId, commentId] })
    await comment.decrement('like_count')
    success(res, { liked: false, like_count: Math.max(0, comment.like_count - 1) })
  } else {
    // 点赞
    await sequelize.query('INSERT INTO comment_likes (user_id, comment_id) VALUES (?, ?)',
      { replacements: [userId, commentId] })
    await comment.increment('like_count')
    success(res, { liked: true, like_count: comment.like_count + 1 })
  }
}

// 批量查询当前用户对一组评论的点赞状态
exports.checkLikes = async (req, res) => {
  const sequelize = require('../config/db')
  const { ids } = req.query  // 逗号分隔 comment ids
  if (!ids) return success(res, [])
  const idArr = ids.split(',').map(Number).filter(Boolean)
  if (!idArr.length) return success(res, [])
  const rows = await sequelize.query(
    `SELECT comment_id FROM comment_likes WHERE user_id = ? AND comment_id IN (?)`,
    { replacements: [req.user.id, idArr], type: sequelize.QueryTypes.SELECT }
  )
  success(res, rows.map(r => r.comment_id))
}

// 上传评论图片（返回可访问的图片 URL）
exports.uploadImage = async (req, res) => {
  if (!req.file) return fail(res, '请上传图片')
  success(res, { url: `/uploads/images/${req.file.filename}` })
}

